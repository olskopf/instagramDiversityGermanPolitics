import base64
import os

DATA_DIR = "data"
ALLOWED_EXTENSIONS = [".jpg", ".jpeg", ".png"]

def save_uploaded_image(party_name: str, content: str, filename: str):
    target_dir = os.path.join(DATA_DIR, party_name)
    os.makedirs(target_dir, exist_ok=True)

    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        return f"⚠️ Nicht unterstütztes Format: {ext}"

    try:
        header, encoded = content.split(',', 1)
        decoded = base64.b64decode(encoded)

        file_path = os.path.join(target_dir, filename)
        with open(file_path, "wb") as f:
            f.write(decoded)

        return f"✅ Bild '{filename}' gespeichert."
    except Exception as e:
        return f"❌ Fehler bei '{filename}': {str(e)}"
