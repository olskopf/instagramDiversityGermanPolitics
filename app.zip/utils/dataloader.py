import os

DATA_DIR = "data"
VALID_EXTENSIONS = (".jpg", ".jpeg", ".png")

def get_account_overview():
    """Gibt ein Dictionary zurück: {account: anzahl_bilder}"""
    overview = {}
    for account in os.listdir(DATA_DIR):
        dir_path = os.path.join(DATA_DIR, account)
        if os.path.isdir(dir_path):
            count = len([
                f for f in os.listdir(dir_path)
                if f.lower().endswith(VALID_EXTENSIONS)
            ])
            overview[account] = count
    return overview
