import dash
from dash import dcc, html, Input, Output, State, ctx
import dash_bootstrap_components as dbc
import os
import shutil
from utils.uploader import save_uploaded_image  # angepasst!
from utils.dataloader import get_account_overview

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.MATERIA])
app.title = "Instagram Diversity Scanner"

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

# ---------- Layout: Tabs ---------- #
app.layout = dbc.Container([
    html.H1("Instagram Diversity Scanner", className="text-center my-4"),
    dbc.Tabs([
        dbc.Tab(label="📥 Datenimport", tab_id="import"),
        dbc.Tab(label="📊 Datenübersicht", tab_id="overview"),
        dbc.Tab(label="📈 Analyse", tab_id="analysis"),
        dbc.Tab(label="⚙️ Einstellungen", tab_id="settings"),
    ], id="tabs", active_tab="import"),
    html.Div(id="tab-content", className="p-4")
])

# ---------- Inhalte der Tabs ---------- #
def render_import_tab():
    return dbc.Row([
        dbc.Col([
            html.H4("Bilder hochladen für eine Partei"),
            dbc.Input(id="party-name", placeholder="Parteiname (z. B. SPD)", type="text"),
            dcc.Upload(
                id="upload",
                children=html.Div(["📤 Bilddateien hier ablegen oder klicken (mehrere erlaubt)"]),
                style={"border": "2px dashed #888", "padding": "40px", "textAlign": "center"},
                multiple=True,
                accept=".jpg,.jpeg,.png"
            ),
            html.Div(id="upload-feedback", className="mt-2 text-muted"),
            html.Div(id="upload-status", className="mt-2 text-danger")
        ], md=6)
    ])


def render_overview_tab():
    overview = get_account_overview()
    cards = []
    for account, count in overview.items():
        cards.append(
            dbc.Card([
                dbc.CardBody([
                    html.H5(account, className="card-title"),
                    html.P(f"{count} Bilder"),
                    dbc.Button("Daten löschen", id={"type": "delete-btn", "index": account}, color="danger", size="sm")
                ])
            ], className="mb-3")
        )
    return html.Div(cards)

def render_analysis_tab():
    return html.Div([
        html.H4("Analyse starten"),
        dbc.Button("Alle Parteien scannen", color="success", className="mb-3"),
        html.Div(id="analysis-visuals")
    ])

def render_settings_tab():
    return html.Div([
        html.H4("Referenzwerte für Deutschland"),
        dbc.Label("Anteil Frauen (%)"),
        dcc.Slider(id="gender-f", min=0, max=100, value=50, marks={i: f"{i}%" for i in range(0, 101, 10)}),
        dbc.Label("Anteil People of Color (%)", className="mt-4"),
        dcc.Slider(id="skin-poc", min=0, max=100, value=25, marks={i: f"{i}%" for i in range(0, 101, 10)}),
        html.Div(id="settings-status", className="mt-3")
    ])

# ---------- Callback zum Rendern der Tabs ---------- #
@app.callback(
    Output("tab-content", "children"),
    Input("tabs", "active_tab")
)
def render_tab_content(active_tab):
    if active_tab == "import":
        return render_import_tab()
    elif active_tab == "overview":
        return render_overview_tab()
    elif active_tab == "analysis":
        return render_analysis_tab()
    elif active_tab == "settings":
        return render_settings_tab()
    return html.P("Fehler: Unbekannter Tab")

# ---------- Callback zum Upload von Bildern ---------- #
@app.callback(
    Output("upload-status", "children"),
    Output("upload-feedback", "children"),
    Input("upload", "contents"),
    State("upload", "filename"),
    State("party-name", "value"),
    prevent_initial_call=True
)
def handle_folder_upload(contents, filenames, party):
    if not contents or not filenames or not party:
        return "", "❌ Ungültiger Upload."

    try:
        saved = 0
        skipped = 0

        for content, filename in zip(contents, filenames):
            result = save_uploaded_image(party, content, filename)
            if result.startswith("✅"):
                saved += 1
            else:
                skipped += 1

        return "", html.Div([
            html.Span("✅ Upload abgeschlossen: "),
            html.Span(f"{saved} Bilder gespeichert, {skipped} Dateien übersprungen.", style={"color": "green"})
        ])

    except Exception as e:
        return "", f"❌ Fehler bei Verarbeitung: {str(e)}"

# ---------- Callback zum Löschen von Datensätzen ---------- #
@app.callback(
    Output("tab-content", "children", allow_duplicate=True),
    Input({"type": "delete-btn", "index": dash.ALL}, "n_clicks"),
    State("tabs", "active_tab"),
    prevent_initial_call=True
)
def delete_dataset(n_clicks_list, active_tab):
    if not any(n_clicks_list):
        return dash.no_update  # Kein Button wurde geklickt

    # Finde das gedrückte Element
    triggered = ctx.triggered_id
    if triggered and "index" in triggered:
        dir_to_remove = os.path.join(DATA_DIR, triggered["index"])
        if os.path.isdir(dir_to_remove):
            shutil.rmtree(dir_to_remove)

    return render_tab_content(active_tab)



if __name__ == '__main__':
    app.run(debug=True)
